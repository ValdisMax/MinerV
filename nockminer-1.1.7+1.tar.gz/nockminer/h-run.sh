#!/usr/bin/env bash

. h-manifest.conf

LOG_FILE="$CUSTOM_LOG_BASENAME.log"
GPU_LIST_FILE="/var/run/hive/nockminer_gpus.conf"
STATS_HELPER="/hive/miners/custom/nockminer/nockminer-stats.sh"
STATS_PIDFILE="/var/run/hive/nockminer_stats.pid"

echo "----------------------------------------------------------------------"
echo "NOCKminer (Original Golden Miner) - 100% to YOUR wallet"
echo "----------------------------------------------------------------------"

# ========== GPU VALIDATION (оставляем — полезно) ==========
GPU_COUNT=$(nvidia-smi -L | wc -l)
if [[ $GPU_COUNT -eq 0 ]]; then
    echo -e "\e[31m[$(date +'%H:%M:%S')] [FATAL] No NVIDIA GPUs detected! Aborting...\e[0m"
    echo "Miner aborted: No NVIDIA GPUs were detected." > "$LOG_FILE"
    exit 1
fi

CONF_CONTENT=$(< ./$CUSTOM_NAME.conf)
GPU_ARG=$(echo "$CONF_CONTENT" | grep -oE -- '--gpu[= ]*[0-9,]+' | head -n1)
CLEAN_CONF="$CONF_CONTENT"
GPU_LIST=""

if [[ -n "$GPU_ARG" ]]; then
    REQUESTED_GPUS_STR=$(echo "$GPU_ARG" | sed -E 's/--gpu[= ]*//')
    CLEAN_CONF=$(echo "$CONF_CONTENT" | sed -E 's/--gpu[= ]*[0-9,]+//g')

    VALIDATED_GPUS=""
    INVALID_GPUS_FOUND=false
    IFS=',' read -ra REQUESTED_GPUS_ARR <<< "$REQUESTED_GPUS_STR"

    for gpu_idx in "${REQUESTED_GPUS_ARR[@]}"; do
        if [[ "$gpu_idx" -ge "$GPU_COUNT" ]]; then
            echo -e "\e[31m[$(date +'%H:%M:%S')] [ERROR] Invalid GPU index: $gpu_idx. Available: 0-$((GPU_COUNT-1))\e[0m"
            INVALID_GPUS_FOUND=true
        else
            [[ -z "$VALIDATED_GPUS" ]] && VALIDATED_GPUS="$gpu_idx" || VALIDATED_GPUS="$VALIDATED_GPUS,$gpu_idx"
        fi
    done

    if [[ "$INVALID_GPUS_FOUND" = true && -z "$VALIDATED_GPUS" ]]; then
        echo -e "\e[31m[$(date +'%H:%M:%S')] [FATAL] Invalid GPU selection. Aborting...\e[0m"
        exit 1
    fi
    GPU_LIST="$VALIDATED_GPUS"
    echo -e "\e[32m[$(date +'%H:%M:%S')] [INFO] Using GPUs: $GPU_LIST\e[0m"
else
    GPU_LIST=$(seq -s, 0 $((GPU_COUNT - 1)))
    echo -e "\e[32m[$(date +'%H:%M:%S')] [INFO] Using all GPUs: $GPU_LIST\e[0m"
fi

echo "$GPU_LIST" > "$GPU_LIST_FILE"

# ========== USER PUBKEY ==========
USER_PUBKEY=$(echo "$CLEAN_CONF" | grep -oE -- '--pubkey[= ]*[^ ]+' | sed -E 's/--pubkey[= ]*//g' | head -n1)
if [[ -z "$USER_PUBKEY" ]]; then
    echo -e "\e[31m[$(date +'%H:%M:%S')] [ERROR] Missing --pubkey in config. Exiting.\e[0m"
    exit 1
fi

# Убираем --pubkey из команды (чтобы не дублировать)
CLEAN_CONF=$(echo "$CLEAN_CONF" | sed -E 's/--pubkey[= ]*[^ ]+//g')

# ========== STATS HELPER (мониторинг) ==========
start_stats_helper() {
    [[ ! -x "$STATS_HELPER" ]] && return
    if [[ -f "$STATS_PIDFILE" ]] && kill -0 "$(cat "$STATS_PIDFILE")" 2>/dev/null; then
        return
    fi
    LOG_FILE="$LOG_FILE" GPU_LIST="$GPU_LIST" USER_PUBKEY="$USER_PUBKEY" "$STATS_HELPER" &
    echo $! > "$STATS_PIDFILE"
}

start_stats_helper

# ========== ЗАПУСК МАЙНЕРА (ЧИСТЫЙ, БЕЗ DEV FEE) ==========
echo -e "\e[32m[$(date +'%H:%M:%S')] [INFO] Starting miner...\e[0m"
echo -e "\e[33m → CUDA_VISIBLE_DEVICES=$GPU_LIST ./nockminer --pubkey=$USER_PUBKEY $CLEAN_CONF\e[0m"

export CUDA_VISIBLE_DEVICES="$GPU_LIST"
exec ./nockminer --pubkey="$USER_PUBKEY" $CLEAN_CONF | tee -a "$LOG_FILE"